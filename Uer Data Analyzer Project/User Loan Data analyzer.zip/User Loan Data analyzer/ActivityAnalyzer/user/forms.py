from django import forms
from user.models import AgentsProfile,AdminUserProfile


class AdminUserProfileForm(forms.ModelForm):
    class Meta:
        model=AdminUserProfile
        fields = ['admin_name','bio','location','email','phonenumber']

class AgentsProfileForm(forms.ModelForm):
    class Meta:
        model=AgentsProfile
        fields = ['firstname','lastname','email','phonenumber','user_age','gender','job','marital','education','housing','location','active_user','salary','term_in_months','interest_rate','loan_amount','personal_loan_taken','loan_sanctioned']
