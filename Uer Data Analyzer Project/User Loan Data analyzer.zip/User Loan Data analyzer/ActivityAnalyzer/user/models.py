from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class AdminUserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    admin_name = models.CharField(max_length=30, blank=True)
    bio = models.CharField(max_length=300, blank=True)
    location = models.CharField(max_length=30, blank=True)
    email = models.EmailField(max_length=30, blank=True)
    phonenumber = models.IntegerField(null=True,blank=True)
    registerd_date = models.DateField(auto_now_add=True,null=True, blank=True)

    def __str__(self):
        return self.admin_name

class AgentsProfile(models.Model):
    admin_user = models.ForeignKey(AdminUserProfile, on_delete=models.CASCADE)
    firstname = models.CharField(max_length=30, blank=True)
    lastname = models.CharField(max_length=30, blank=True)
    email = models.EmailField(max_length=30, blank=True)
    phonenumber = models.IntegerField()
    user_age = models.IntegerField()
    gender=models.CharField(max_length=30, blank=True, null=True)
    job = models.CharField(max_length=30, blank=True)
    marital = models.CharField(max_length=30, blank=True)
    education = models.CharField(max_length=30, blank=True)
    housing = models.CharField(max_length=30, blank=True)
    location = models.CharField(max_length=30, blank=True)
    active_user=models.CharField(max_length=30, blank=True)
    salary = models.CharField(max_length=30, blank=True)
    term_in_months = models.IntegerField()
    interest_rate = models.FloatField()
    loan_amount = models.CharField(max_length=30, blank=True)
    personal_loan_taken = models.CharField(max_length=30, blank=True)
    loan_sanctioned = models.CharField(max_length=30, blank=True)

    def __str__(self):
        return self.firstname
