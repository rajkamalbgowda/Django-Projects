from django.contrib import admin
from .models import AdminUserProfile, AgentsProfile

# Register your models here.
class AdminUserProfileAdmin(admin.ModelAdmin):
    list_display = ['id', 'user','admin_name','bio','location','email','phonenumber','registerd_date']
admin.site.register(AdminUserProfile, AdminUserProfileAdmin)

class AgentsProfileAdmin(admin.ModelAdmin):
    list_display = ['id', 'admin_user','firstname','lastname','email','phonenumber','user_age','gender','job','marital','education','housing','location','active_user','salary','term_in_months','interest_rate','loan_amount','personal_loan_taken','loan_sanctioned']
admin.site.register(AgentsProfile, AgentsProfileAdmin)
