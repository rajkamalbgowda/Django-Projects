from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from user.models import AgentsProfile,AdminUserProfile
from user.forms import AdminUserProfileForm,AgentsProfileForm
from django.contrib.auth.models import User
import json
from collections import Counter


# Create your views here.
def loginpage(request):
    if request.method=='POST':
        form = AuthenticationForm()
        uname=request.POST['username']
        upass=request.POST['password']
        user=authenticate(username=uname,password=upass)
        if user is None:
            messages.info(request, 'Username or Password entered is not correct')
            return redirect('/loginpage')
        else:
            login(request, user)
            return redirect('/admin_dashboard')
    else:
            form = AuthenticationForm()
            return render(request, 'login.html', {'form':form})

def registerpage(request):
    form = UserCreationForm()
    if request.method=='POST':
        form=UserCreationForm(request.POST)
        if form.is_valid():
            form.save()

            user_name=form['username'].value()
            User_obj=User.objects.get(username=user_name)
            admin_user_obj=AdminUserProfile(user=User_obj)
            admin_user_obj.save()


            messages.add_message(request,messages.INFO, 'User Successfully Registered')
            return redirect('/loginpage')
    return render(request, 'register.html', {'form':form})

def logout_func(request):
    if request.user.is_authenticated:
        logout(request)
        messages.info(request,'You have been successfully Logged out')
    return redirect('/loginpage')



def admin_dashboard(request):
    if request.user.is_authenticated:
        user_id=request.user.id
        admin_object=AdminUserProfile.objects.get(user=user_id)

        if admin_object.admin_name=='':
            bank_name='Admin Name'
        else:
            bank_name=admin_object.admin_name

        if admin_object.bio=='':
            bank_bio='Enter the bio here'
        else:
            bank_bio=admin_object.bio

        #for table data
        agent_object=AgentsProfile.objects.filter(admin_user=admin_object)

        #for age distribution
        total_age_list=[]
        age_heading_list=['Username','Age']
        total_age_list.append(age_heading_list)

        for data in  agent_object:
            age_list=[data.firstname,data.user_age]
            total_age_list.append(age_list)
        total_age_list_json=json.dumps(total_age_list)



        #for gender analysis count
        female_count=agent_object.filter(gender='Female').count()
        male_count=agent_object.filter(gender='Male').count()
        male_count_json=json.dumps(male_count)
        female_count_json=json.dumps(female_count)

        #loan given analysis
        total_number_of_agents=agent_object.count()
        agents_sanctioned_with_loan=agent_object.filter(loan_sanctioned='yes').count()
        agents_not_sanctioned_with_loan=agent_object.filter(loan_sanctioned='no').count()

        total_number_of_agents_json=json.dumps(total_number_of_agents)
        agents_sanctioned_with_loan_json=json.dumps(agents_sanctioned_with_loan)
        agents_not_sanctioned_with_loan_json=json.dumps(agents_not_sanctioned_with_loan)


        #marital analysis count
        married_count=agent_object.filter(marital='married').count()
        single_count=agent_object.filter(marital='single').count()
        married_count_json=json.dumps(married_count)
        single_count_json=json.dumps(single_count)

        #job analysis
        no_job=agent_object.filter(job='No Job').count()
        software_engineer=agent_object.filter(job='software engineer').count()
        Teacher=agent_object.filter(job='Teacher').count()
        Enterpreuner=agent_object.filter(job='Enterpreuner').count()
        Farmer=agent_object.filter(job='Farmer').count()

        no_job_json=json.dumps(no_job)
        software_engineer_json=json.dumps(software_engineer)
        Teacher_json=json.dumps(Teacher)
        Enterpreuner_json=json.dumps(Enterpreuner)
        Farmer_json=json.dumps(Farmer)

        #salary distribution
        salary_dist_list=[]
        sal_dist_heading_list=['Username','Salary']
        salary_dist_list.append(sal_dist_heading_list)

        for data in  agent_object:
            sal_list=[data.firstname,data.salary]
            salary_dist_list.append(sal_list)
        salary_dist_list_json=json.dumps(salary_dist_list)

        #interest rate distribution
        interest_dist_list=[]
        int_dist_heading_list=['Username','Interest Rate']
        interest_dist_list.append(int_dist_heading_list)

        for data in  agent_object:
            int_list=[data.firstname,data.interest_rate]
            interest_dist_list.append(int_list)
        interest_dist_list_json=json.dumps(interest_dist_list)

        #Location analysis
        location_number_list=[]
        location_number_heading_list=['Location', 'Number of people']
        location_number_list.append(location_number_heading_list)

        location_list=[]
        for data in agent_object:
            location_list.append(data.location)
        unique_locations=list(Counter(location_list).keys())
        location_number=list(Counter(location_list).values())

        for i in range(len(unique_locations)):
            empty_list=[]
            empty_list.append(unique_locations[i])
            empty_list.append(location_number[i])
            location_number_list.append(empty_list)


        #Scatterplot
        scatter_plot_main_list=[['Salary','Loan Sanctioned']]

        for  data in agent_object:
            empty_list=[]
            empty_list.append(data.salary)
            if data.loan_sanctioned=='yes':
                empty_list.append(1)
            if data.loan_sanctioned=='no':
                empty_list.append(0)
            scatter_plot_main_list.append(empty_list)
        print(scatter_plot_main_list)



        return render(request,'admin_dashboard.html',{'scatter_plot_main_list':scatter_plot_main_list,'location_number_list':location_number_list,'interest_dist_list_json':interest_dist_list_json,'salary_dist_list_json':salary_dist_list_json,'Farmer_json':Farmer_json,'Enterpreuner_json':Enterpreuner_json,'Teacher_json':Teacher_json,'software_engineer_json':software_engineer_json,'no_job_json':no_job_json,'single_count_json':single_count_json,'married_count_json':married_count_json,'agents_not_sanctioned_with_loan_json':agents_not_sanctioned_with_loan_json,'agents_sanctioned_with_loan_json':agents_sanctioned_with_loan_json,'total_number_of_agents_json':total_number_of_agents_json,'female_count_json':female_count_json,'male_count_json':male_count_json,'total_age_list_json':total_age_list_json,'agent_object':agent_object,'bank_name':bank_name,'bank_bio':bank_bio})

    else:
        messages.info(request, 'You need to login first')
    return redirect('/loginpage')

def edit_admin(request):
    if request.user.is_authenticated:
        user_id=request.user.id
        admin_object=AdminUserProfile.objects.get(user=user_id)
        bank_name=admin_object.admin_name
        bank_bio=admin_object.bio

        admin_edit_form=AdminUserProfileForm(instance=admin_object)
        if request.method=='POST':
            admin_edit_form=AdminUserProfileForm(request.POST,instance=admin_object)
            admin_edit_form.save()
            return redirect('admin_dashboard')
    return render(request,'edit_admin.html',{'bank_name':bank_name,'bank_bio':bank_bio,'admin_edit_form':admin_edit_form})

def add_agent(request):
    if request.user.is_authenticated:
        user_id=request.user.id
        admin_object=AdminUserProfile.objects.get(user=user_id)
        bank_name=admin_object.admin_name
        bank_bio=admin_object.bio

        agent_form=AgentsProfileForm()
        if request.method == "POST":
            agent_form=AgentsProfileForm(request.POST)
            obj = agent_form.save(commit=False)
            obj.admin_user = admin_object
            obj.save()
            return redirect('admin_dashboard')
    return render(request,'add_agent.html',{'agent_form':agent_form,'bank_name':bank_name,'bank_bio':bank_bio,})
