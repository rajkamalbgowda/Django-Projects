from django.urls import path
from . import views

urlpatterns=[
    path('loginpage', views.loginpage, name='loginpage'),
    path('registerpage', views.registerpage, name='registerpage'),
    path('admin_dashboard', views.admin_dashboard, name='admin_dashboard'),
    path('logout', views.logout_func, name='logout_func'),
    path('edit_admin', views.edit_admin, name='edit_admin'),
    path('add_agent', views.add_agent, name='add_agent'),



]
